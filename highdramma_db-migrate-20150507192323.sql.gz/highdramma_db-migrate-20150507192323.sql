# WordPress MySQL database migration
#
# Generated: Thursday 7. May 2015 19:23 UTC
# Hostname: localhost
# Database: `highdramma_db`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-04-13 18:19:28', '2015-04-13 18:19:28', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=661 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://highdramma.lisawolfsonmyers.com', 'yes'),
(2, 'home', 'http://highdramma.lisawolfsonmyers.com', 'yes'),
(3, 'blogname', 'High Dramma', 'yes'),
(4, 'blogdescription', 'The online home of one of the finest sketch comedy troupes in Philadelphia.', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'lwolfson@mcad.edu', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:37:"ai-twitter-feeds/ai-twitter-feeds.php";i:2;s:19:"akismet/akismet.php";i:3;s:23:"developer/developer.php";i:4;s:34:"facebook-feed-grabber/facebook.php";i:6;s:33:"monster-widget/monster-widget.php";i:7;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '0', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'highdramma', 'yes'),
(42, 'stylesheet', 'highdramma', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '31533', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '0', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:2:{s:37:"ai-twitter-feeds/ai-twitter-feeds.php";s:24:"ai_twitterfeed_uninstall";s:33:"rotatingtweets/rotatingtweets.php";s:24:"rotatingtweets_uninstall";}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '21', 'yes'),
(85, 'page_on_front', '19', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '30133', 'yes'),
(89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:1:{i:0;s:38:"widget-easy-twitter-feed-widget-kamn-2";}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:5:{i:1431027600;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1431066027;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1431107479;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1431109245;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(105, 'auth_key', 'M<g:y50ev>Gpv6MwCFF|8Ru~5/{y+9KGNtO nE0b1Q7`v D^St$`*cRhjG}3>+A&', 'yes'),
(106, 'auth_salt', '1c$,G!wzZ wPr-5aD#vR%=|qAP%lDp1j})V-<zRy.(WuO{fXn}b689Q/@u-hS#uz', 'yes'),
(107, 'logged_in_key', 'FoQQv]r`P1imYoLEV2*/ygN^YFn9r>d7Vn(0m4IZplV]%8}S/KXjP1D^oeq+{! N', 'yes'),
(108, 'logged_in_salt', '9gTc7~?wB?`hf0t6e79_1~5vQ?`z3M_iWmFTWVi8K3ngZx5]><55WdMe2qV_70Hh', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(109, 'nonce_key', 'e3gd~ypOwZT1xa9co [a7H,jQa,m;;f@PlX7nX/3Gb8GAa5rb6!)>`M3`z4F4Sn7', 'yes'),
(110, 'nonce_salt', '-sK8}o8B>27{v`Kauf(nJUMVKdEE|`z7l[AVM5l^{hom>>Tu}FJr,b.9`N_gh^(:', 'yes'),
(135, 'recently_activated', 'a:1:{s:19:"jetpack/jetpack.php";i:1431026428;}', 'yes'),
(136, 'acf_version', '5.2.2', 'yes'),
(138, 'a8c_developer', 'a:1:{s:12:"project_type";s:5:"wporg";}', 'yes'),
(221, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1429206757;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(222, 'current_theme', 'highdramma', 'yes'),
(223, 'theme_mods_highdramma', 'a:3:{i:0;b:0;s:12:"header_image";s:13:"remove-header";s:18:"nav_menu_locations";a:3:{s:7:"primary";i:2;s:7:"members";i:4;s:6:"social";i:5;}}', 'yes'),
(224, 'theme_switched', '', 'yes'),
(251, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(291, 'category_children', 'a:0:{}', 'yes'),
(355, 'kamn_easy_twitter_feed_widget_options', 'a:2:{s:44:"kamn_easy_twitter_feed_widget_script_control";i:1;s:43:"kamn_easy_twitter_feed_widget_reset_control";i:0;}', 'yes'),
(356, 'widget_widget-easy-twitter-feed-widget-kamn', 'a:2:{i:2;a:15:{s:5:"title";s:14:"Twitter Widget";s:17:"twitter_widget_id";s:18:"344713329262084096";s:26:"twitter_widget_screen_name";s:10:"highdramma";s:26:"twitter_widget_tweet_limit";s:1:"3";s:27:"twitter_widget_show_replies";s:5:"false";s:20:"twitter_widget_width";s:3:"180";s:21:"twitter_widget_height";s:3:"200";s:20:"twitter_widget_theme";s:5:"light";s:25:"twitter_widget_link_color";s:0:"";s:27:"twitter_widget_border_color";s:0:"";s:28:"twitter_widget_chrome_header";s:1:"1";s:28:"twitter_widget_chrome_footer";s:1:"0";s:28:"twitter_widget_chrome_border";s:1:"0";s:31:"twitter_widget_chrome_scrollbar";s:1:"1";s:32:"twitter_widget_chrome_background";s:1:"1";}s:12:"_multiwidget";i:1;}', 'yes'),
(412, 'ai_consumer_screen_name', 'highdramma', 'yes'),
(413, 'ai_consumer_key', '0u476FbLORc3ur1EW2W4rfg28', 'yes'),
(414, 'ai_consumer_secret', 'opdpA1U3SCm9zPfOB7LhbqtCFPX2Xz1bDa4PZ13738wouc5IdM', 'yes'),
(415, 'ai_access_token', '30478463-k6VOtaqgLdPOn4yzL5ptN1xs6UAhK0CKLU2W5sgMl', 'yes'),
(416, 'ai_access_token_secret', 'WnMZlQBosFAaO06mjGE08ajDQSGj19L4XEwEEZdI36CKx', 'yes'),
(417, 'ai_display_number_of_tweets', '3', 'yes'),
(418, 'ai_twitter_css', '', 'yes'),
(423, 'ffg_options', 'a:14:{s:6:"app_id";s:15:"469899993159677";s:6:"secret";s:32:"19836af51034fc57e67c5f05947e166a";s:12:"default_feed";s:15:"195967877193581";s:10:"show_title";i:1;s:10:"cache_feed";i:5;s:12:"cache_folder";s:64:"/home2/lwolfson/public_html/highdramma/wp-content/uploads/cache/";s:11:"num_entries";i:3;s:6:"locale";s:5:"en_US";s:9:"proxy_url";s:0:"";s:5:"limit";i:1;s:15:"show_thumbnails";i:1;s:11:"style_sheet";s:11:"style-2.css";s:14:"delete_options";i:0;s:7:"version";s:5:"0.8.4";}', 'yes'),
(533, 'db_upgraded', '', 'yes'),
(536, 'rewrite_rules', 'a:82:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:39:"member-bios/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:49:"member-bios/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:69:"member-bios/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"member-bios/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:64:"member-bios/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:32:"member-bios/([^/]+)/trackback/?$";s:33:"index.php?member=$matches[1]&tb=1";s:40:"member-bios/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?member=$matches[1]&paged=$matches[2]";s:47:"member-bios/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?member=$matches[1]&cpage=$matches[2]";s:32:"member-bios/([^/]+)(/[0-9]+)?/?$";s:45:"index.php?member=$matches[1]&page=$matches[2]";s:28:"member-bios/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:38:"member-bios/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:58:"member-bios/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"member-bios/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:53:"member-bios/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=19&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'),
(537, 'can_compress_scripts', '1', 'yes'),
(625, 'jetpack_file_data', 'a:1:{s:5:"3.5.3";a:48:{s:32:"9ff0bb607142458f86ae1a9dc6651311";a:13:{s:4:"name";s:20:"Spelling and Grammar";s:11:"description";s:89:"Check your spelling, style, and grammar with the After the Deadline proofreading service.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"6";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";}s:32:"680d6735a9e8ccc3ea65dd9d38ade8ba";a:13:{s:4:"name";s:8:"Carousel";s:11:"description";s:63:"Transform standard image galleries into full-screen slideshows.";s:14:"jumpstart_desc";s:79:"brings your photos and images to life as full-size, easily navigable galleries.";s:4:"sort";s:2:"22";s:20:"recommendation_order";s:2:"12";s:10:"introduced";s:3:"1.5";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:17:"Photos and Videos";s:7:"feature";s:9:"Jumpstart";}s:32:"40a14795a29e684ed47dd4903fbab123";a:13:{s:4:"name";s:16:"Jetpack Comments";s:11:"description";s:79:"Let readers comment with WordPress.com, Twitter, Facebook, or Google+ accounts.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"20";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.4";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:6:"Social";s:7:"feature";s:0:"";}s:32:"8a43bc08023c96a90be5db36b5f30293";a:13:{s:4:"name";s:12:"Contact Form";s:11:"description";s:44:"Insert a contact form anywhere on your site.";s:14:"jumpstart_desc";s:111:"adds a button to your post and page editors, allowing you to build simple forms to help visitors stay in touch.";s:4:"sort";s:2:"15";s:20:"recommendation_order";s:2:"14";s:10:"introduced";s:3:"1.3";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:5:"Other";s:7:"feature";s:9:"Jumpstart";}s:32:"71e76d4b3966732ce0375e5236f3bf20";a:13:{s:4:"name";s:20:"Custom Content Types";s:11:"description";s:92:"Organize and display different types of content on your site, separate from posts and pages.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"34";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"3.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";}s:32:"aeafcd08c0afcffdd59ca950af95b52c";a:13:{s:4:"name";s:10:"Custom CSS";s:11:"description";s:57:"Customize your site’s CSS without modifying your theme.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"2";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.7";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:10:"Appearance";s:7:"feature";s:0:"";}s:32:"d2476600857315556a54b3f3ec10a4b6";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"0927b346b0b85bad67e902ee51fd7ae7";a:13:{s:4:"name";s:21:"Enhanced Distribution";s:11:"description";s:74:"Share your public posts and comments to search engines and other services.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"5";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:6:"Public";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";}s:32:"68e6f38b72a962b4ee8bd02fc34ba0ba";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"b755f6d8bf889a07abf89fe227c86bb2";a:13:{s:4:"name";s:19:"Gravatar Hovercards";s:11:"description";s:58:"Enable pop-up business cards over commenters’ Gravatars.";s:14:"jumpstart_desc";s:131:"let commenters link their profiles to their Gravatar accounts, making it easy for your visitors to learn more about your community.";s:4:"sort";s:2:"11";s:20:"recommendation_order";s:2:"13";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:18:"Social, Appearance";s:7:"feature";s:9:"Jumpstart";}s:32:"3e9d755cfb2d5f824621ef72ae4734ad";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:8:"2.0.3 ??";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"427f194a69fad16a6cc9feb01b7dd056";a:13:{s:4:"name";s:15:"Infinite Scroll";s:11:"description";s:46:"Add support for infinite scroll to your theme.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"26";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:10:"Appearance";s:7:"feature";s:0:"";}s:32:"5e31eb1f20c32f07dc4b26a29ec04e16";a:13:{s:4:"name";s:8:"JSON API";s:11:"description";s:69:"Allow applications to securely access your content through the cloud.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"19";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.9";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:6:"Public";s:11:"module_tags";s:19:"Writing, Developers";s:7:"feature";s:0:"";}s:32:"087ff26db4ff7faf4eb2fdecad43fd0c";a:13:{s:4:"name";s:14:"Beautiful Math";s:11:"description";s:85:"Use LaTeX markup language in posts and pages for complex equations and other geekery.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"12";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";}s:32:"617fe11b873f385616a45584c9dedbfc";a:13:{s:4:"name";s:5:"Likes";s:11:"description";s:70:"Give visitors an easy way to show their appreciation for your content.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"23";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:6:"Social";s:7:"feature";s:0:"";}s:32:"34e4f3455b5a1714ee531d9593d0eff5";a:13:{s:4:"name";s:6:"Manage";s:11:"description";s:76:"Manage all your sites from a centralized place, https://wordpress.com/sites.";s:14:"jumpstart_desc";s:151:"helps you remotely manage plugins, turn on automated updates, and more from <a href="https://wordpress.com/plugins/" target="_blank">wordpress.com</a>.";s:4:"sort";s:1:"1";s:20:"recommendation_order";s:1:"3";s:10:"introduced";s:3:"3.4";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:35:"Centralized Management, Recommended";s:7:"feature";s:22:"Recommended, Jumpstart";}s:32:"02d2c262789d5463f6c553decd275fb2";a:13:{s:4:"name";s:8:"Markdown";s:11:"description";s:51:"Write posts or pages in plain-text Markdown syntax.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"31";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.8";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";}s:32:"8f04cace49dcc257650b277b37b44e1a";a:13:{s:4:"name";s:12:"Mobile Theme";s:11:"description";s:64:"Optimize your site with a mobile-friendly theme for smartphones.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"21";s:20:"recommendation_order";s:2:"11";s:10:"introduced";s:3:"1.8";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:31:"Appearance, Mobile, Recommended";s:7:"feature";s:11:"Recommended";}s:32:"ddd34c8e14670ea51d371788ea2cb87b";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"026c9f7003c78ceb2dc1f75a2d14b20b";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"dc5586cf9a5b693bf118d3dddcbf6f2c";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"5fc1da468d164289885178896a794c97";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"fe83c4bf72ee73b25128684e5cc08b21";a:13:{s:4:"name";s:7:"Monitor";s:11:"description";s:88:"Receive notifications from Jetpack if your site goes offline — and when it it returns.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"28";s:20:"recommendation_order";s:2:"10";s:10:"introduced";s:3:"2.6";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:11:"Recommended";s:7:"feature";s:11:"Recommended";}s:32:"6c93cf544fa448572bc3e5a8f0ae3bae";a:13:{s:4:"name";s:13:"Notifications";s:11:"description";s:84:"Receive notification of site activity via the admin toolbar and your Mobile devices.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"13";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.9";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:5:"Other";s:7:"feature";s:0:"";}s:32:"33c95980e736dae9ec04d361f8db9a74";a:13:{s:4:"name";s:10:"Omnisearch";s:11:"description";s:66:"Search your entire database from a single field in your Dashboard.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"16";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.3";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:10:"Developers";s:7:"feature";s:0:"";}s:32:"07599b54d484ade3d0078ee2bf7c5b66";a:13:{s:4:"name";s:6:"Photon";s:11:"description";s:66:"Accelerate your site by loading images from the WordPress.com CDN.";s:14:"jumpstart_desc";s:141:"mirrors and serves your images from our free and fast image CDN, improving your site’s performance with no additional load on your servers.";s:4:"sort";s:2:"25";s:20:"recommendation_order";s:1:"1";s:10:"introduced";s:3:"2.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:42:"Photos and Videos, Appearance, Recommended";s:7:"feature";s:22:"Recommended, Jumpstart";}s:32:"781993fb18eedc42c193c26a5a4c6b75";a:13:{s:4:"name";s:13:"Post by Email";s:11:"description";s:58:"Publish posts by email, using any device and email client.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"14";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";}s:32:"b2afdeb70b16147e93c0610d3bd8d448";a:13:{s:4:"name";s:7:"Protect";s:11:"description";s:70:"Adds brute force protection to your login page. Formerly BruteProtect.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"1";s:20:"recommendation_order";s:1:"4";s:10:"introduced";s:3:"3.4";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:11:"Recommended";s:7:"feature";s:11:"Recommended";}s:32:"83f658edea01c6465c5024273b763b37";a:13:{s:4:"name";s:9:"Publicize";s:11:"description";s:55:"Share new posts on social media networks automatically.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"10";s:20:"recommendation_order";s:1:"7";s:10:"introduced";s:3:"2.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:19:"Social, Recommended";s:7:"feature";s:11:"Recommended";}s:32:"326d17b4cdce856a71f492e93e489a7b";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"e35e28e53219844167a6c469c83efda6";a:13:{s:4:"name";s:13:"Related Posts";s:11:"description";s:60:"Display links to your related content under posts and pages.";s:14:"jumpstart_desc";s:113:"keep visitors engaged on your blog by highlighting relevant and new content at the bottom of each published post.";s:4:"sort";s:2:"29";s:20:"recommendation_order";s:1:"9";s:10:"introduced";s:3:"2.9";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:11:"Recommended";s:7:"feature";s:22:"Recommended, Jumpstart";}s:32:"f19e215977ee2ac347a9cbe199572b54";a:13:{s:4:"name";s:7:"Sharing";s:11:"description";s:81:"Allow visitors to share your content on Facebook, Twitter, and more with a click.";s:14:"jumpstart_desc";s:116:"Twitter, Facebook and Google+ buttons at the bottom of each post, making it easy for visitors to share your content.";s:4:"sort";s:1:"7";s:20:"recommendation_order";s:1:"6";s:10:"introduced";s:3:"1.1";s:7:"changed";s:3:"1.2";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:19:"Social, Recommended";s:7:"feature";s:22:"Recommended, Jumpstart";}s:32:"1bd53a4d875cee7b1b7d938079bd9bac";a:13:{s:4:"name";s:16:"Shortcode Embeds";s:11:"description";s:77:"Embed content from YouTube, Vimeo, SlideShare, and more, no coding necessary.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"3";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.1";s:7:"changed";s:3:"1.2";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:46:"Photos and Videos, Social, Writing, Appearance";s:7:"feature";s:0:"";}s:32:"654500b10eec4edf53e4cbe52ba4b77a";a:13:{s:4:"name";s:16:"WP.me Shortlinks";s:11:"description";s:56:"Enable WP.me-powered shortlinks for all posts and pages.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"8";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:6:"Social";s:7:"feature";s:0:"";}s:32:"8d49375c0a01a9cede8109c61312bcad";a:13:{s:4:"name";s:9:"Site Icon";s:11:"description";s:29:"Add a site icon to your site.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"22";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"3.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:5:"Other";s:7:"feature";s:0:"";}s:32:"10eaeebf7e5e02255e54c5ffafaab7fa";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"ae166a551ae0045c9564073969dbf3d1";a:13:{s:4:"name";s:22:"Jetpack Single Sign On";s:11:"description";s:62:"Allow your users to log in using their WordPress.com accounts.";s:14:"jumpstart_desc";s:97:"lets you login to all your Jetpack-enabled sites with one click using your WordPress.com account.";s:4:"sort";s:2:"30";s:20:"recommendation_order";s:1:"5";s:10:"introduced";s:3:"2.6";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:10:"Developers";s:7:"feature";s:9:"Jumpstart";}s:32:"06d7af30002b4b362128996240fe0af0";a:13:{s:4:"name";s:19:"WordPress.com Stats";s:11:"description";s:85:"Monitor your stats with clear, concise reports and no additional load on your server.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"1";s:20:"recommendation_order";s:1:"2";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:32:"WordPress.com Stats, Recommended";s:7:"feature";s:11:"Recommended";}s:32:"8cc0b638cbce5a11b9d0a907f1e59eb7";a:13:{s:4:"name";s:13:"Subscriptions";s:11:"description";s:88:"Allow users to subscribe to your posts and comments and receive notifications via email.";s:14:"jumpstart_desc";s:126:"give visitors two easy subscription options — while commenting, or via a separate email subscription widget you can display.";s:4:"sort";s:1:"9";s:20:"recommendation_order";s:1:"8";s:10:"introduced";s:3:"1.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:6:"Social";s:7:"feature";s:9:"Jumpstart";}s:32:"ef371757915961d985c6f7df641bcbb1";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"34cbbbb2be1486ae1f95fc5d806023cc";a:13:{s:4:"name";s:15:"Tiled Galleries";s:11:"description";s:73:"Display your image galleries in a variety of sleek, graphic arrangements.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"24";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:17:"Photos and Videos";s:7:"feature";s:0:"";}s:32:"8838106a3e5c9d14798488221cfc837c";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"ec448b38c195c13db6d9ec6dbafa50c0";a:13:{s:4:"name";s:10:"VaultPress";s:11:"description";s:85:"Protect your site with automatic backups and security scans. (Subscription required.)";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"32";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:5:"0:1.2";s:7:"changed";s:0:"";s:10:"deactivate";s:5:"false";s:4:"free";s:5:"false";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"43ecd72da738feb9b7c8dc4caf7efbf4";a:13:{s:4:"name";s:17:"Site Verification";s:11:"description";s:78:"Verify your site or domain with Google Webmaster Tools, Pinterest, and others.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"33";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"3.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}s:32:"9256d09be87a3e2cf4f8f6f7e3bcae13";a:13:{s:4:"name";s:10:"VideoPress";s:11:"description";s:68:"Upload and embed videos right on your site. (Subscription required.)";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"27";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.5";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:5:"false";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:17:"Photos and Videos";s:7:"feature";s:0:"";}s:32:"56328c6ec3cc726cc26e422ea3951710";a:13:{s:4:"name";s:17:"Widget Visibility";s:11:"description";s:57:"Specify which widgets appear on which pages of your site.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"17";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.4";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:10:"Appearance";s:7:"feature";s:0:"";}s:32:"08c3005da2093ee54d6285f0198a21ee";a:13:{s:4:"name";s:21:"Extra Sidebar Widgets";s:11:"description";s:79:"Add images, Twitter streams, your site’s RSS links, and more to your sidebar.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"4";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:18:"Social, Appearance";s:7:"feature";s:0:"";}s:32:"7a43628bf0c7e08934c978c63762c342";a:13:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";}}}', 'yes'),
(626, 'jetpack_available_modules', 'a:1:{s:5:"3.5.3";a:36:{s:18:"after-the-deadline";s:3:"1.1";s:8:"carousel";s:3:"1.5";s:8:"comments";s:3:"1.4";s:12:"contact-form";s:3:"1.3";s:20:"custom-content-types";s:3:"3.1";s:10:"custom-css";s:3:"1.7";s:21:"enhanced-distribution";s:3:"1.2";s:19:"gravatar-hovercards";s:3:"1.1";s:15:"infinite-scroll";s:3:"2.0";s:8:"json-api";s:3:"1.9";s:5:"latex";s:3:"1.1";s:5:"likes";s:3:"2.2";s:6:"manage";s:3:"3.4";s:8:"markdown";s:3:"2.8";s:9:"minileven";s:3:"1.8";s:7:"monitor";s:3:"2.6";s:5:"notes";s:3:"1.9";s:10:"omnisearch";s:3:"2.3";s:6:"photon";s:3:"2.0";s:13:"post-by-email";s:3:"2.0";s:7:"protect";s:3:"3.4";s:9:"publicize";s:3:"2.0";s:13:"related-posts";s:3:"2.9";s:10:"sharedaddy";s:3:"1.1";s:10:"shortcodes";s:3:"1.1";s:10:"shortlinks";s:3:"1.1";s:9:"site-icon";s:3:"3.2";s:3:"sso";s:3:"2.6";s:5:"stats";s:3:"1.1";s:13:"subscriptions";s:3:"1.2";s:13:"tiled-gallery";s:3:"2.1";s:10:"vaultpress";s:5:"0:1.2";s:18:"verification-tools";s:3:"3.0";s:10:"videopress";s:3:"2.5";s:17:"widget-visibility";s:3:"2.4";s:7:"widgets";s:3:"1.2";}}', 'yes'),
(628, 'jetpack_security_report', 'a:0:{}', 'yes'),
(633, 'jetpack_log', 'a:2:{i:0;a:5:{s:4:"time";i:1431021511;s:7:"user_id";i:1;s:7:"blog_id";b:0;s:4:"code";s:8:"activate";s:4:"data";s:9:"minileven";}i:1;a:5:{s:4:"time";i:1431021564;s:7:"user_id";i:1;s:7:"blog_id";b:0;s:4:"code";s:8:"activate";s:4:"data";s:9:"site-icon";}}', 'no'),
(635, 'wp_mobile_excerpt', '0', 'yes'),
(636, 'wp_mobile_featured_images', '1', 'yes'),
(637, 'wp_mobile_app_promos', '0', 'yes'),
(641, 'jetpack_site_icon_id', '129', 'yes'),
(642, 'jetpack_site_icon_url', 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/05/hd-site-icon-554ba897v1_site_icon.png', 'yes'),
(648, 'jetpack_updates', 'a:7:{s:7:"plugins";i:0;s:6:"themes";i:0;s:9:"wordpress";i:0;s:12:"translations";i:0;s:5:"total";i:0;s:10:"wp_version";s:5:"4.2.1";s:26:"site_is_version_controlled";b:1;}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=703 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(7, 5, '_wp_attached_file', '2015/04/hd-logo-200x208.png'),
(8, 5, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:208;s:4:"file";s:27:"2015/04/hd-logo-200x208.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"hd-logo-200x208-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(37, 19, '_edit_last', '1'),
(38, 19, '_edit_lock', '1430934333:1'),
(39, 21, '_edit_last', '1'),
(40, 21, '_edit_lock', '1429293430:1'),
(41, 23, '_edit_last', '1'),
(42, 23, '_edit_lock', '1430534474:1'),
(43, 25, '_edit_last', '1'),
(44, 25, '_edit_lock', '1429293456:1'),
(45, 27, '_edit_last', '1'),
(46, 27, '_edit_lock', '1429293469:1'),
(47, 29, '_menu_item_type', 'post_type'),
(48, 29, '_menu_item_menu_item_parent', '0'),
(49, 29, '_menu_item_object_id', '27'),
(50, 29, '_menu_item_object', 'page'),
(51, 29, '_menu_item_target', ''),
(52, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(53, 29, '_menu_item_xfn', ''),
(54, 29, '_menu_item_url', ''),
(56, 30, '_menu_item_type', 'post_type'),
(57, 30, '_menu_item_menu_item_parent', '0'),
(58, 30, '_menu_item_object_id', '25'),
(59, 30, '_menu_item_object', 'page'),
(60, 30, '_menu_item_target', ''),
(61, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(62, 30, '_menu_item_xfn', ''),
(63, 30, '_menu_item_url', ''),
(65, 31, '_menu_item_type', 'post_type'),
(66, 31, '_menu_item_menu_item_parent', '0'),
(67, 31, '_menu_item_object_id', '23'),
(68, 31, '_menu_item_object', 'page'),
(69, 31, '_menu_item_target', ''),
(70, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(71, 31, '_menu_item_xfn', ''),
(72, 31, '_menu_item_url', ''),
(74, 32, '_menu_item_type', 'post_type'),
(75, 32, '_menu_item_menu_item_parent', '0'),
(76, 32, '_menu_item_object_id', '21'),
(77, 32, '_menu_item_object', 'page'),
(78, 32, '_menu_item_target', ''),
(79, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(80, 32, '_menu_item_xfn', ''),
(81, 32, '_menu_item_url', ''),
(83, 33, '_wp_trash_meta_status', 'auto-draft'),
(84, 33, '_wp_trash_meta_time', '1429293690'),
(85, 1, '_wp_trash_meta_status', 'publish'),
(86, 1, '_wp_trash_meta_time', '1429458671'),
(87, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(88, 35, '_edit_last', '1'),
(89, 35, '_edit_lock', '1429465407:1'),
(90, 41, '_edit_last', '1'),
(91, 41, '_edit_lock', '1429459738:1'),
(92, 41, '_wp_trash_meta_status', 'draft'),
(93, 41, '_wp_trash_meta_time', '1429459753'),
(94, 44, '_edit_last', '1'),
(95, 44, '_edit_lock', '1429466494:1'),
(96, 45, '_wp_attached_file', '2015/04/jax-madlibs-biopic.jpg'),
(97, 45, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:217;s:6:"height";i:208;s:4:"file";s:30:"2015/04/jax-madlibs-biopic.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"jax-madlibs-biopic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(98, 45, '_wp_attachment_image_alt', 'Jax does madlibs'),
(99, 44, 'members_title', 'Actor/Writer/Company Manager'),
(100, 44, '_members_title', 'field_5533cf7ab87d4'),
(101, 44, 'quote_motto', 'High-minded vulgarity, low-brow sophistication'),
(102, 44, '_quote_motto', 'field_5533cf93b87d5'),
(103, 44, 'member_photo', '45'),
(104, 44, '_member_photo', 'field_5533cfd7b87d6'),
(105, 44, 'member_bio', 'Jackie hails from the great, warm state of Minnesota. She graduated from the University of Minnesota with a Journalism degree, and there she performed in shows such as <em>A Lesson in Dead Language</em>, and the world premier of <em>Working</em>. She also studied acting at The Betty Ann Norton Theater School in Dublin, Ireland.\r\n\r\nTo date, her favorite shows have been <em>Mr. Marmalade</em> (Bradley), <em>Nunsense II: The Second Coming</em> (Mother Superior) and <em>The Glass Menagerie</em> (Amanda Wingfield). An original member of High Dramma, and company manager, Jackie hopes to continue writing and acting with the group until 2012, when the world’s supposed to end. And, if it doesn’t end, well, that will just be awkward for everyone.'),
(106, 44, '_member_bio', 'field_5533d02db87d7'),
(107, 44, 'member_favorites_0_sketch', 'Greeting Cards'),
(108, 44, '_member_favorites_0_sketch', 'field_5533d4e9c6c7e'),
(109, 44, 'member_favorites', 'a:1:{i:0;s:17:"favorite_sketches";}'),
(110, 44, '_member_favorites', 'field_5533d4b2c6c7d'),
(111, 50, '_edit_last', '1'),
(112, 50, '_edit_lock', '1429461015:1'),
(113, 44, 'favorite_sketches_0_favorite_sketch', 'Greeting Cards'),
(114, 44, '_favorite_sketches_0_favorite_sketch', 'field_5533d5f6feaf5'),
(115, 44, 'favorite_sketches_1_favorite_sketch', 'Somalian Pirate Sing-along'),
(116, 44, '_favorite_sketches_1_favorite_sketch', 'field_5533d5f6feaf5'),
(117, 44, 'favorite_sketches_2_favorite_sketch', 'Gyno'),
(118, 44, '_favorite_sketches_2_favorite_sketch', 'field_5533d5f6feaf5'),
(119, 44, 'favorite_sketches_3_favorite_sketch', 'Bleached A**hole'),
(120, 44, '_favorite_sketches_3_favorite_sketch', 'field_5533d5f6feaf5'),
(121, 44, 'favorite_sketches_4_favorite_sketch', 'Beauty and the Beast'),
(122, 44, '_favorite_sketches_4_favorite_sketch', 'field_5533d5f6feaf5'),
(123, 44, 'favorite_sketches', '5'),
(124, 44, '_favorite_sketches', 'field_5533d5dffeaf4'),
(125, 44, 'memorable_characters_0_memorable_character', 'a terrible Richard Nixon'),
(126, 44, '_memorable_characters_0_memorable_character', 'field_5533d637feaf7'),
(127, 44, 'memorable_characters_1_memorable_character', 'a worse Ozzy Osbourne'),
(128, 44, '_memorable_characters_1_memorable_character', 'field_5533d637feaf7'),
(129, 44, 'memorable_characters_2_memorable_character', 'a dead grandma'),
(130, 44, '_memorable_characters_2_memorable_character', 'field_5533d637feaf7'),
(131, 44, 'memorable_characters', '3'),
(132, 44, '_memorable_characters', 'field_5533d624feaf6'),
(133, 44, 'comedic_idols_0_comedic_idol', 'Kristen Schaal'),
(134, 44, '_comedic_idols_0_comedic_idol', 'field_5533d67cfeaf9'),
(135, 44, 'comedic_idols_1_comedic_idol', 'Mindy Kaling'),
(136, 44, '_comedic_idols_1_comedic_idol', 'field_5533d67cfeaf9'),
(137, 44, 'comedic_idols_2_comedic_idol', 'Tina Fey/Amy Pohler (they cannot be separated or favored one over the other)'),
(138, 44, '_comedic_idols_2_comedic_idol', 'field_5533d67cfeaf9') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(139, 44, 'comedic_idols', '3'),
(140, 44, '_comedic_idols', 'field_5533d66dfeaf8'),
(141, 57, '_edit_last', '1'),
(142, 57, 'members_title', ''),
(143, 57, '_members_title', 'field_5533cf7ab87d4'),
(144, 57, 'quote_motto', ''),
(145, 57, '_quote_motto', 'field_5533cf93b87d5'),
(146, 57, 'member_photo', ''),
(147, 57, '_member_photo', 'field_5533cfd7b87d6'),
(148, 57, 'member_bio', ''),
(149, 57, '_member_bio', 'field_5533d02db87d7'),
(150, 57, 'favorite_sketches', '0'),
(151, 57, '_favorite_sketches', 'field_5533d5dffeaf4'),
(152, 57, 'memorable_characters', '0'),
(153, 57, '_memorable_characters', 'field_5533d624feaf6'),
(154, 57, 'comedic_idols', '0'),
(155, 57, '_comedic_idols', 'field_5533d66dfeaf8'),
(156, 57, '_edit_lock', '1429466506:1'),
(157, 58, '_edit_last', '1'),
(158, 58, 'members_title', ''),
(159, 58, '_members_title', 'field_5533cf7ab87d4'),
(160, 58, 'quote_motto', ''),
(161, 58, '_quote_motto', 'field_5533cf93b87d5'),
(162, 58, 'member_photo', ''),
(163, 58, '_member_photo', 'field_5533cfd7b87d6'),
(164, 58, 'member_bio', ''),
(165, 58, '_member_bio', 'field_5533d02db87d7'),
(166, 58, 'favorite_sketches', '0'),
(167, 58, '_favorite_sketches', 'field_5533d5dffeaf4'),
(168, 58, 'memorable_characters', '0'),
(169, 58, '_memorable_characters', 'field_5533d624feaf6'),
(170, 58, 'comedic_idols', '0'),
(171, 58, '_comedic_idols', 'field_5533d66dfeaf8'),
(172, 58, '_edit_lock', '1429466515:1'),
(173, 59, '_edit_last', '1'),
(174, 59, 'members_title', ''),
(175, 59, '_members_title', 'field_5533cf7ab87d4'),
(176, 59, 'quote_motto', ''),
(177, 59, '_quote_motto', 'field_5533cf93b87d5'),
(178, 59, 'member_photo', ''),
(179, 59, '_member_photo', 'field_5533cfd7b87d6'),
(180, 59, 'member_bio', ''),
(181, 59, '_member_bio', 'field_5533d02db87d7'),
(182, 59, 'favorite_sketches', '0'),
(183, 59, '_favorite_sketches', 'field_5533d5dffeaf4'),
(184, 59, 'memorable_characters', '0'),
(185, 59, '_memorable_characters', 'field_5533d624feaf6'),
(186, 59, 'comedic_idols', '0'),
(187, 59, '_comedic_idols', 'field_5533d66dfeaf8'),
(188, 59, '_edit_lock', '1429466523:1'),
(189, 60, '_edit_last', '1'),
(190, 60, 'members_title', ''),
(191, 60, '_members_title', 'field_5533cf7ab87d4'),
(192, 60, 'quote_motto', ''),
(193, 60, '_quote_motto', 'field_5533cf93b87d5'),
(194, 60, 'member_photo', ''),
(195, 60, '_member_photo', 'field_5533cfd7b87d6'),
(196, 60, 'member_bio', ''),
(197, 60, '_member_bio', 'field_5533d02db87d7'),
(198, 60, 'favorite_sketches', '0'),
(199, 60, '_favorite_sketches', 'field_5533d5dffeaf4'),
(200, 60, 'memorable_characters', '0'),
(201, 60, '_memorable_characters', 'field_5533d624feaf6'),
(202, 60, 'comedic_idols', '0'),
(203, 60, '_comedic_idols', 'field_5533d66dfeaf8'),
(204, 60, '_edit_lock', '1429642333:1'),
(205, 61, '_menu_item_type', 'post_type'),
(206, 61, '_menu_item_menu_item_parent', '0'),
(207, 61, '_menu_item_object_id', '60'),
(208, 61, '_menu_item_object', 'member'),
(209, 61, '_menu_item_target', ''),
(210, 61, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(211, 61, '_menu_item_xfn', ''),
(212, 61, '_menu_item_url', ''),
(214, 62, '_menu_item_type', 'post_type'),
(215, 62, '_menu_item_menu_item_parent', '0'),
(216, 62, '_menu_item_object_id', '59'),
(217, 62, '_menu_item_object', 'member'),
(218, 62, '_menu_item_target', ''),
(219, 62, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(220, 62, '_menu_item_xfn', ''),
(221, 62, '_menu_item_url', ''),
(223, 63, '_menu_item_type', 'post_type'),
(224, 63, '_menu_item_menu_item_parent', '0'),
(225, 63, '_menu_item_object_id', '58'),
(226, 63, '_menu_item_object', 'member'),
(227, 63, '_menu_item_target', ''),
(228, 63, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(229, 63, '_menu_item_xfn', ''),
(230, 63, '_menu_item_url', ''),
(232, 64, '_menu_item_type', 'post_type'),
(233, 64, '_menu_item_menu_item_parent', '0'),
(234, 64, '_menu_item_object_id', '57'),
(235, 64, '_menu_item_object', 'member'),
(236, 64, '_menu_item_target', ''),
(237, 64, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(238, 64, '_menu_item_xfn', ''),
(239, 64, '_menu_item_url', ''),
(241, 65, '_menu_item_type', 'post_type'),
(242, 65, '_menu_item_menu_item_parent', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(243, 65, '_menu_item_object_id', '44'),
(244, 65, '_menu_item_object', 'member'),
(245, 65, '_menu_item_target', ''),
(246, 65, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(247, 65, '_menu_item_xfn', ''),
(248, 65, '_menu_item_url', ''),
(250, 66, '_menu_item_type', 'custom'),
(251, 66, '_menu_item_menu_item_parent', '0'),
(252, 66, '_menu_item_object_id', '66'),
(253, 66, '_menu_item_object', 'custom'),
(254, 66, '_menu_item_target', ''),
(255, 66, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(256, 66, '_menu_item_xfn', ''),
(257, 66, '_menu_item_url', 'http://www.facebook.com/HighDramma'),
(259, 67, '_menu_item_type', 'custom'),
(260, 67, '_menu_item_menu_item_parent', '0'),
(261, 67, '_menu_item_object_id', '67'),
(262, 67, '_menu_item_object', 'custom'),
(263, 67, '_menu_item_target', ''),
(264, 67, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(265, 67, '_menu_item_xfn', ''),
(266, 67, '_menu_item_url', 'http://twitter.com/highdramma'),
(268, 68, '_menu_item_type', 'custom'),
(269, 68, '_menu_item_menu_item_parent', '0'),
(270, 68, '_menu_item_object_id', '68'),
(271, 68, '_menu_item_object', 'custom'),
(272, 68, '_menu_item_target', ''),
(273, 68, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(274, 68, '_menu_item_xfn', ''),
(275, 68, '_menu_item_url', 'http://www.youtube.com/user/HighDramma'),
(277, 69, '_edit_last', '1'),
(278, 69, '_edit_lock', '1430934481:1'),
(279, 75, '_wp_attached_file', '2015/04/mandudebro-and-hd.jpg'),
(280, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:266;s:4:"file";s:29:"2015/04/mandudebro-and-hd.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"mandudebro-and-hd-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"mandudebro-and-hd-300x111.jpg";s:5:"width";i:300;s:6:"height";i:111;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(281, 75, '_wp_attachment_image_alt', 'ManDudeBro and HD'),
(282, 19, '_wp_page_template', 'default'),
(283, 76, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(284, 76, '_homepage_introduction', 'field_55353a9ea92f4'),
(285, 76, 'featured_section_0_featured_image', '75'),
(286, 76, '_featured_section_0_featured_image', 'field_55353b32a92f6'),
(287, 76, 'featured_section_0_featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(288, 76, '_featured_section_0_featured_title', 'field_55353b62a92f7'),
(289, 76, 'featured_section_0_featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday at 9pm for a Steelstacks show with the fine young men of ManDudeBro!'),
(290, 76, '_featured_section_0_featured_content', 'field_55353b90a92f8'),
(291, 76, 'featured_section', 'a:1:{i:0;s:16:"featured_section";}'),
(292, 76, '_featured_section', 'field_55353b02a92f5'),
(293, 19, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(294, 19, '_homepage_introduction', 'field_55353a9ea92f4'),
(295, 19, 'featured_section_0_featured_image', '75'),
(296, 19, '_featured_section_0_featured_image', 'field_55353b32a92f6'),
(297, 19, 'featured_section_0_featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(298, 19, '_featured_section_0_featured_title', 'field_55353b62a92f7'),
(299, 19, 'featured_section_0_featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday at 9pm for a Steelstacks show with the fine young men of ManDudeBro!'),
(300, 19, '_featured_section_0_featured_content', 'field_55353b90a92f8'),
(301, 19, 'featured_section', 'a:1:{i:0;s:16:"featured_section";}'),
(302, 19, '_featured_section', 'field_55353b02a92f5'),
(303, 80, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(304, 80, '_homepage_introduction', 'field_55353a9ea92f4'),
(305, 80, 'featured_image', '75'),
(306, 80, '_featured_image', 'field_553540ab94dd2'),
(307, 80, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(308, 80, '_featured_title', 'field_553540c194dd3'),
(309, 80, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(310, 80, '_featured_content', 'field_553540d394dd4'),
(311, 19, 'featured_image', '75'),
(312, 19, '_featured_image', 'field_553540ab94dd2'),
(313, 19, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(314, 19, '_featured_title', 'field_553540c194dd3'),
(315, 19, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(316, 19, '_featured_content', 'field_553540d394dd4'),
(317, 81, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(318, 81, '_homepage_introduction', 'field_55353a9ea92f4'),
(319, 81, 'featured_image', '75'),
(320, 81, '_featured_image', 'field_553540ab94dd2'),
(321, 81, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(322, 81, '_featured_title', 'field_553540c194dd3'),
(323, 81, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(324, 81, '_featured_content', 'field_553540d394dd4'),
(325, 82, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(326, 82, '_homepage_introduction', 'field_55353a9ea92f4'),
(327, 82, 'featured_image', '75'),
(328, 82, '_featured_image', 'field_553540ab94dd2'),
(329, 82, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(330, 82, '_featured_title', 'field_553540c194dd3'),
(331, 82, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(332, 82, '_featured_content', 'field_553540d394dd4'),
(333, 84, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.\r\n\r\n&nbsp;\r\n\r\n[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(334, 84, '_homepage_introduction', 'field_55353a9ea92f4'),
(335, 84, 'featured_image', '75'),
(336, 84, '_featured_image', 'field_553540ab94dd2'),
(337, 84, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(338, 84, '_featured_title', 'field_553540c194dd3'),
(339, 84, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(340, 84, '_featured_content', 'field_553540d394dd4'),
(341, 88, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.\r\n\r\n&nbsp;\r\n\r\n[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(342, 88, '_homepage_introduction', 'field_55353a9ea92f4'),
(343, 88, 'featured_image', '75'),
(344, 88, '_featured_image', 'field_553540ab94dd2'),
(345, 88, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(346, 88, '_featured_title', 'field_553540c194dd3') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(347, 88, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(348, 88, '_featured_content', 'field_553540d394dd4'),
(349, 88, 'facebook_feed', '[fb_feed]'),
(350, 88, '_facebook_feed', 'field_553d32f209498'),
(351, 88, 'youtube_feed', ''),
(352, 88, '_youtube_feed', 'field_553d332309499'),
(353, 88, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(354, 88, '_twitter_feed', 'field_553d332f0949a'),
(355, 19, 'facebook_feed', '[fb_feed]'),
(356, 19, '_facebook_feed', 'field_553d32f209498'),
(357, 19, 'youtube_feed', '2'),
(358, 19, '_youtube_feed', 'field_553d332309499'),
(359, 19, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(360, 19, '_twitter_feed', 'field_553d332f0949a'),
(361, 89, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.\r\n\r\n&nbsp;\r\n\r\n[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(362, 89, '_homepage_introduction', 'field_55353a9ea92f4'),
(363, 89, 'featured_image', '75'),
(364, 89, '_featured_image', 'field_553540ab94dd2'),
(365, 89, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(366, 89, '_featured_title', 'field_553540c194dd3'),
(367, 89, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(368, 89, '_featured_content', 'field_553540d394dd4'),
(369, 89, 'facebook_feed', '[fb_feed]'),
(370, 89, '_facebook_feed', 'field_553d32f209498'),
(371, 89, 'youtube_feed', '[youtube=https://www.youtube.com/watch?v=Ri0Rk_j6ezk&w=162&h=115]'),
(372, 89, '_youtube_feed', 'field_553d332309499'),
(373, 89, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(374, 89, '_twitter_feed', 'field_553d332f0949a'),
(375, 90, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.\r\n\r\n&nbsp;\r\n\r\n[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(376, 90, '_homepage_introduction', 'field_55353a9ea92f4'),
(377, 90, 'featured_image', '75'),
(378, 90, '_featured_image', 'field_553540ab94dd2'),
(379, 90, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(380, 90, '_featured_title', 'field_553540c194dd3'),
(381, 90, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(382, 90, '_featured_content', 'field_553540d394dd4'),
(383, 90, 'facebook_feed', '[fb_feed]'),
(384, 90, '_facebook_feed', 'field_553d32f209498'),
(385, 90, 'youtube_feed', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(386, 90, '_youtube_feed', 'field_553d332309499'),
(387, 90, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(388, 90, '_twitter_feed', 'field_553d332f0949a'),
(389, 91, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(390, 91, '_homepage_introduction', 'field_55353a9ea92f4'),
(391, 91, 'featured_image', '75'),
(392, 91, '_featured_image', 'field_553540ab94dd2'),
(393, 91, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(394, 91, '_featured_title', 'field_553540c194dd3'),
(395, 91, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(396, 91, '_featured_content', 'field_553540d394dd4'),
(397, 91, 'facebook_feed', '[fb_feed]'),
(398, 91, '_facebook_feed', 'field_553d32f209498'),
(399, 91, 'youtube_feed', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(400, 91, '_youtube_feed', 'field_553d332309499'),
(401, 91, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(402, 91, '_twitter_feed', 'field_553d332f0949a'),
(403, 92, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.\r\n\r\n&nbsp;\r\n\r\n[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(404, 92, '_homepage_introduction', 'field_55353a9ea92f4'),
(405, 92, 'featured_image', '75'),
(406, 92, '_featured_image', 'field_553540ab94dd2'),
(407, 92, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(408, 92, '_featured_title', 'field_553540c194dd3'),
(409, 92, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(410, 92, '_featured_content', 'field_553540d394dd4'),
(411, 92, 'facebook_feed', '[fb_feed]'),
(412, 92, '_facebook_feed', 'field_553d32f209498'),
(413, 92, 'youtube_feed', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(414, 92, '_youtube_feed', 'field_553d332309499'),
(415, 92, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(416, 92, '_twitter_feed', 'field_553d332f0949a'),
(417, 93, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(418, 93, '_homepage_introduction', 'field_55353a9ea92f4'),
(419, 93, 'featured_image', '75'),
(420, 93, '_featured_image', 'field_553540ab94dd2'),
(421, 93, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(422, 93, '_featured_title', 'field_553540c194dd3'),
(423, 93, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(424, 93, '_featured_content', 'field_553540d394dd4'),
(425, 93, 'facebook_feed', '[fb_feed]'),
(426, 93, '_facebook_feed', 'field_553d32f209498'),
(427, 93, 'youtube_feed', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(428, 93, '_youtube_feed', 'field_553d332309499'),
(429, 93, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(430, 93, '_twitter_feed', 'field_553d332f0949a'),
(431, 97, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(432, 97, '_homepage_introduction', 'field_55353a9ea92f4'),
(433, 97, 'featured_image', '75'),
(434, 97, '_featured_image', 'field_553540ab94dd2'),
(435, 97, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(436, 97, '_featured_title', 'field_553540c194dd3'),
(437, 97, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(438, 97, '_featured_content', 'field_553540d394dd4'),
(439, 97, 'facebook_feed', ''),
(440, 97, '_facebook_feed', 'field_553d32f209498'),
(441, 97, 'youtube_feed', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(442, 97, '_youtube_feed', 'field_553d332309499'),
(443, 97, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(444, 97, '_twitter_feed', 'field_553d332f0949a'),
(445, 97, 'social_media_feeds_0_social_media_name', 'Facebook Feed'),
(446, 97, '_social_media_feeds_0_social_media_name', 'field_553d496677465') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(447, 97, 'social_media_feeds_0_social_media_shortcode', '[fb_feed]'),
(448, 97, '_social_media_feeds_0_social_media_shortcode', 'field_553d497a77466'),
(449, 97, 'social_media_feeds', '1'),
(450, 97, '_social_media_feeds', 'field_553d493377464'),
(455, 19, 'social_media_feeds', '0'),
(456, 19, '_social_media_feeds', 'field_553d493377464'),
(457, 98, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(458, 98, '_homepage_introduction', 'field_55353a9ea92f4'),
(459, 98, 'featured_image', '75'),
(460, 98, '_featured_image', 'field_553540ab94dd2'),
(461, 98, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(462, 98, '_featured_title', 'field_553540c194dd3'),
(463, 98, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(464, 98, '_featured_content', 'field_553540d394dd4'),
(465, 98, 'facebook_feed', ''),
(466, 98, '_facebook_feed', 'field_553d32f209498'),
(467, 98, 'youtube_feed', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(468, 98, '_youtube_feed', 'field_553d332309499'),
(469, 98, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(470, 98, '_twitter_feed', 'field_553d332f0949a'),
(471, 98, 'social_media_feeds_0_social_media_name', 'High Dramma on Facebook'),
(472, 98, '_social_media_feeds_0_social_media_name', 'field_553d496677465'),
(473, 98, 'social_media_feeds_0_social_media_shortcode', '[fb_feed]'),
(474, 98, '_social_media_feeds_0_social_media_shortcode', 'field_553d497a77466'),
(475, 98, 'social_media_feeds_1_social_media_name', 'Latest HD YouTube Video'),
(476, 98, '_social_media_feeds_1_social_media_name', 'field_553d496677465'),
(477, 98, 'social_media_feeds_1_social_media_shortcode', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(478, 98, '_social_media_feeds_1_social_media_shortcode', 'field_553d497a77466'),
(479, 98, 'social_media_feeds_2_social_media_name', 'HighDramma Tweets'),
(480, 98, '_social_media_feeds_2_social_media_name', 'field_553d496677465'),
(481, 98, 'social_media_feeds_2_social_media_shortcode', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(482, 98, '_social_media_feeds_2_social_media_shortcode', 'field_553d497a77466'),
(483, 98, 'social_media_feeds', '3'),
(484, 98, '_social_media_feeds', 'field_553d493377464'),
(493, 99, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(494, 99, '_homepage_introduction', 'field_55353a9ea92f4'),
(495, 99, 'featured_image', '75'),
(496, 99, '_featured_image', 'field_553540ab94dd2'),
(497, 99, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(498, 99, '_featured_title', 'field_553540c194dd3'),
(499, 99, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(500, 99, '_featured_content', 'field_553540d394dd4'),
(501, 99, 'facebook_feed', ''),
(502, 99, '_facebook_feed', 'field_553d32f209498'),
(503, 99, 'youtube_feed', ''),
(504, 99, '_youtube_feed', 'field_553d332309499'),
(505, 99, 'twitter_feed', ''),
(506, 99, '_twitter_feed', 'field_553d332f0949a'),
(507, 99, 'social_media_feeds_0_social_media_name', 'High Dramma on Facebook'),
(508, 99, '_social_media_feeds_0_social_media_name', 'field_553d496677465'),
(509, 99, 'social_media_feeds_0_social_media_shortcode', '[fb_feed]'),
(510, 99, '_social_media_feeds_0_social_media_shortcode', 'field_553d497a77466'),
(511, 99, 'social_media_feeds_1_social_media_name', 'Latest HD YouTube Video'),
(512, 99, '_social_media_feeds_1_social_media_name', 'field_553d496677465'),
(513, 99, 'social_media_feeds_1_social_media_shortcode', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(514, 99, '_social_media_feeds_1_social_media_shortcode', 'field_553d497a77466'),
(515, 99, 'social_media_feeds_2_social_media_name', 'HighDramma Tweets'),
(516, 99, '_social_media_feeds_2_social_media_name', 'field_553d496677465'),
(517, 99, 'social_media_feeds_2_social_media_shortcode', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(518, 99, '_social_media_feeds_2_social_media_shortcode', 'field_553d497a77466'),
(519, 99, 'social_media_feeds', '3'),
(520, 99, '_social_media_feeds', 'field_553d493377464'),
(521, 100, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(522, 100, '_homepage_introduction', 'field_55353a9ea92f4'),
(523, 100, 'featured_image', '75'),
(524, 100, '_featured_image', 'field_553540ab94dd2'),
(525, 100, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(526, 100, '_featured_title', 'field_553540c194dd3'),
(527, 100, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(528, 100, '_featured_content', 'field_553540d394dd4'),
(529, 100, 'facebook_feed', '[fb_feed]'),
(530, 100, '_facebook_feed', 'field_553d32f209498'),
(531, 100, 'youtube_feed', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(532, 100, '_youtube_feed', 'field_553d332309499'),
(533, 100, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(534, 100, '_twitter_feed', 'field_553d332f0949a'),
(535, 100, 'social_media_feeds', '0'),
(536, 100, '_social_media_feeds', 'field_553d493377464'),
(537, 101, '_menu_item_type', 'post_type'),
(538, 101, '_menu_item_menu_item_parent', '30'),
(539, 101, '_menu_item_object_id', '60'),
(540, 101, '_menu_item_object', 'member'),
(541, 101, '_menu_item_target', ''),
(542, 101, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(543, 101, '_menu_item_xfn', ''),
(544, 101, '_menu_item_url', ''),
(546, 102, '_menu_item_type', 'post_type'),
(547, 102, '_menu_item_menu_item_parent', '30'),
(548, 102, '_menu_item_object_id', '59'),
(549, 102, '_menu_item_object', 'member'),
(550, 102, '_menu_item_target', ''),
(551, 102, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(552, 102, '_menu_item_xfn', ''),
(553, 102, '_menu_item_url', ''),
(555, 103, '_menu_item_type', 'post_type'),
(556, 103, '_menu_item_menu_item_parent', '30'),
(557, 103, '_menu_item_object_id', '58'),
(558, 103, '_menu_item_object', 'member'),
(559, 103, '_menu_item_target', ''),
(560, 103, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(561, 103, '_menu_item_xfn', ''),
(562, 103, '_menu_item_url', ''),
(564, 104, '_menu_item_type', 'post_type'),
(565, 104, '_menu_item_menu_item_parent', '30'),
(566, 104, '_menu_item_object_id', '57'),
(567, 104, '_menu_item_object', 'member'),
(568, 104, '_menu_item_target', ''),
(569, 104, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(570, 104, '_menu_item_xfn', ''),
(571, 104, '_menu_item_url', ''),
(573, 105, '_menu_item_type', 'post_type'),
(574, 105, '_menu_item_menu_item_parent', '30'),
(575, 105, '_menu_item_object_id', '44'),
(576, 105, '_menu_item_object', 'member'),
(577, 105, '_menu_item_target', ''),
(578, 105, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(579, 105, '_menu_item_xfn', ''),
(580, 105, '_menu_item_url', ''),
(582, 106, '_edit_last', '1'),
(583, 106, '_edit_lock', '1430533606:1'),
(584, 23, '_wp_page_template', 'default'),
(585, 110, 'sketch_videos_0_video_of_sketch', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(586, 110, '_sketch_videos_0_video_of_sketch', 'field_554411170e8e2'),
(587, 110, 'sketch_videos_1_video_of_sketch', 'https://www.youtube.com/watch?v=0t2GjQCzXsc'),
(588, 110, '_sketch_videos_1_video_of_sketch', 'field_554411170e8e2'),
(589, 110, 'sketch_videos_2_video_of_sketch', 'https://www.youtube.com/watch?v=EoIWHt-CCd8'),
(590, 110, '_sketch_videos_2_video_of_sketch', 'field_554411170e8e2'),
(591, 110, 'sketch_videos_3_video_of_sketch', 'https://www.youtube.com/watch?v=pBRrX0Eanho'),
(592, 110, '_sketch_videos_3_video_of_sketch', 'field_554411170e8e2'),
(593, 110, 'sketch_videos', '4'),
(594, 110, '_sketch_videos', 'field_554410f00e8e1'),
(595, 110, 'sketch_photos', ''),
(596, 110, '_sketch_photos', 'field_554411500e8e3'),
(597, 23, 'sketch_videos_0_video_of_sketch', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(598, 23, '_sketch_videos_0_video_of_sketch', 'field_554411170e8e2'),
(599, 23, 'sketch_videos_1_video_of_sketch', 'https://www.youtube.com/watch?v=0t2GjQCzXsc'),
(600, 23, '_sketch_videos_1_video_of_sketch', 'field_554411170e8e2'),
(601, 23, 'sketch_videos_2_video_of_sketch', 'https://www.youtube.com/watch?v=EoIWHt-CCd8'),
(602, 23, '_sketch_videos_2_video_of_sketch', 'field_554411170e8e2'),
(603, 23, 'sketch_videos_3_video_of_sketch', 'https://www.youtube.com/watch?v=pBRrX0Eanho'),
(604, 23, '_sketch_videos_3_video_of_sketch', 'field_554411170e8e2'),
(605, 23, 'sketch_videos', '4'),
(606, 23, '_sketch_videos', 'field_554410f00e8e1'),
(607, 23, 'sketch_photos', 'a:10:{i:0;s:3:"111";i:1;s:3:"112";i:2;s:3:"113";i:3;s:3:"114";i:4;s:3:"115";i:5;s:3:"116";i:6;s:3:"117";i:7;s:3:"118";i:8;s:3:"119";i:9;s:3:"120";}'),
(608, 23, '_sketch_photos', 'field_554411500e8e3'),
(609, 111, '_wp_attached_file', '2015/04/bananas.jpg'),
(610, 111, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3456;s:6:"height";i:2304;s:4:"file";s:19:"2015/04/bananas.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"bananas-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"bananas-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"bananas-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4;s:6:"credit";s:0:"";s:6:"camera";s:13:"Canon EOS 50D";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1271924005;s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"28";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:15:"0.0166666666667";s:5:"title";s:0:"";s:11:"orientation";i:1;}}'),
(611, 112, '_wp_attached_file', '2015/04/broken-fish.jpg'),
(612, 112, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2100;s:6:"height";i:1758;s:4:"file";s:23:"2015/04/broken-fish.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"broken-fish-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"broken-fish-300x251.jpg";s:5:"width";i:300;s:6:"height";i:251;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"broken-fish-1024x857.jpg";s:5:"width";i:1024;s:6:"height";i:857;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4;s:6:"credit";s:0:"";s:6:"camera";s:13:"Canon EOS 50D";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1271925372;s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"32";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:15:"0.0166666666667";s:5:"title";s:0:"";s:11:"orientation";i:1;}}'),
(613, 113, '_wp_attached_file', '2015/04/cannibals.jpg'),
(614, 113, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:604;s:6:"height";i:403;s:4:"file";s:21:"2015/04/cannibals.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"cannibals-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"cannibals-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(615, 114, '_wp_attached_file', '2015/04/high-five.jpg'),
(616, 114, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:604;s:6:"height";i:403;s:4:"file";s:21:"2015/04/high-five.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"high-five-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"high-five-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(617, 115, '_wp_attached_file', '2015/04/high-five2.jpg'),
(618, 115, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:604;s:6:"height";i:403;s:4:"file";s:22:"2015/04/high-five2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"high-five2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"high-five2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(619, 116, '_wp_attached_file', '2015/04/mexican-holdup.jpg'),
(620, 116, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:604;s:6:"height";i:403;s:4:"file";s:26:"2015/04/mexican-holdup.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"mexican-holdup-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"mexican-holdup-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(621, 117, '_wp_attached_file', '2015/04/nuts.jpg'),
(622, 117, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:604;s:6:"height";i:403;s:4:"file";s:16:"2015/04/nuts.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"nuts-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:16:"nuts-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(623, 118, '_wp_attached_file', '2015/04/poor-luigi.jpg'),
(624, 118, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:604;s:6:"height";i:403;s:4:"file";s:22:"2015/04/poor-luigi.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"poor-luigi-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"poor-luigi-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(625, 119, '_wp_attached_file', '2015/04/singing-suit.jpg'),
(626, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:604;s:6:"height";i:403;s:4:"file";s:24:"2015/04/singing-suit.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"singing-suit-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"singing-suit-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(627, 120, '_wp_attached_file', '2015/04/the-lineup.jpg'),
(628, 120, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:604;s:6:"height";i:402;s:4:"file";s:22:"2015/04/the-lineup.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"the-lineup-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"the-lineup-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(629, 111, '_wp_attachment_image_alt', 'Climax of Bananas'),
(630, 112, '_wp_attachment_image_alt', 'A fish vs a cop'),
(631, 113, '_wp_attachment_image_alt', 'Part of Cannibals'),
(632, 114, '_wp_attachment_image_alt', 'Group in front of a sign'),
(633, 115, '_wp_attachment_image_alt', 'Group debating'),
(634, 116, '_wp_attachment_image_alt', 'A typical stick-up'),
(635, 117, '_wp_attachment_image_alt', 'Girls selling nuts'),
(636, 118, '_wp_attachment_image_alt', 'Mario and Luigi'),
(637, 119, '_wp_attachment_image_alt', 'Suit salesman and singer'),
(638, 120, '_wp_attachment_image_alt', 'Group in a lineup'),
(639, 121, 'sketch_videos_0_video_of_sketch', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(640, 121, '_sketch_videos_0_video_of_sketch', 'field_554411170e8e2'),
(641, 121, 'sketch_videos_1_video_of_sketch', 'https://www.youtube.com/watch?v=0t2GjQCzXsc'),
(642, 121, '_sketch_videos_1_video_of_sketch', 'field_554411170e8e2'),
(643, 121, 'sketch_videos_2_video_of_sketch', 'https://www.youtube.com/watch?v=EoIWHt-CCd8'),
(644, 121, '_sketch_videos_2_video_of_sketch', 'field_554411170e8e2'),
(645, 121, 'sketch_videos_3_video_of_sketch', 'https://www.youtube.com/watch?v=pBRrX0Eanho'),
(646, 121, '_sketch_videos_3_video_of_sketch', 'field_554411170e8e2'),
(647, 121, 'sketch_videos', '4'),
(648, 121, '_sketch_videos', 'field_554410f00e8e1'),
(649, 121, 'sketch_photos', 'a:10:{i:0;s:3:"111";i:1;s:3:"112";i:2;s:3:"113";i:3;s:3:"114";i:4;s:3:"115";i:5;s:3:"116";i:6;s:3:"117";i:7;s:3:"118";i:8;s:3:"119";i:9;s:3:"120";}'),
(650, 121, '_sketch_photos', 'field_554411500e8e3'),
(651, 23, 'gallery', 'a:10:{i:0;s:3:"120";i:1;s:3:"118";i:2;s:3:"119";i:3;s:3:"116";i:4;s:3:"117";i:5;s:3:"114";i:6;s:3:"115";i:7;s:3:"113";i:8;s:3:"112";i:9;s:3:"111";}'),
(652, 23, '_gallery', 'field_554411500e8e3'),
(653, 124, 'sketch_videos_title', 'The latest sketch videos from High Dramma'),
(654, 124, '_sketch_videos_title', 'field_55443634e80ac'),
(655, 124, 'sketch_videos_0_video_of_sketch', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(656, 124, '_sketch_videos_0_video_of_sketch', 'field_554411170e8e2'),
(657, 124, 'sketch_videos_1_video_of_sketch', 'https://www.youtube.com/watch?v=0t2GjQCzXsc'),
(658, 124, '_sketch_videos_1_video_of_sketch', 'field_554411170e8e2'),
(659, 124, 'sketch_videos_2_video_of_sketch', 'https://www.youtube.com/watch?v=EoIWHt-CCd8'),
(660, 124, '_sketch_videos_2_video_of_sketch', 'field_554411170e8e2'),
(661, 124, 'sketch_videos_3_video_of_sketch', 'https://www.youtube.com/watch?v=pBRrX0Eanho'),
(662, 124, '_sketch_videos_3_video_of_sketch', 'field_554411170e8e2'),
(663, 124, 'sketch_videos', '4') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(664, 124, '_sketch_videos', 'field_554410f00e8e1'),
(665, 124, 'sketch_photos_title', 'Photos of High Dramma in action'),
(666, 124, '_sketch_photos_title', 'field_55443651e80ad'),
(667, 124, 'gallery', 'a:10:{i:0;s:3:"120";i:1;s:3:"118";i:2;s:3:"119";i:3;s:3:"116";i:4;s:3:"117";i:5;s:3:"114";i:6;s:3:"115";i:7;s:3:"113";i:8;s:3:"112";i:9;s:3:"111";}'),
(668, 124, '_gallery', 'field_554411500e8e3'),
(669, 23, 'sketch_videos_title', 'The latest sketch videos from High Dramma'),
(670, 23, '_sketch_videos_title', 'field_55443634e80ac'),
(671, 23, 'sketch_photos_title', 'Photos of High Dramma in action'),
(672, 23, '_sketch_photos_title', 'field_55443651e80ad'),
(673, 126, 'featured_image', '75'),
(674, 126, '_featured_image', 'field_553540ab94dd2'),
(675, 126, 'featured_title', 'Mark Your Hopefully Unmarked Calendars'),
(676, 126, '_featured_title', 'field_553540c194dd3'),
(677, 126, 'featured_content', 'High Dramma is returning to the Lehigh Valley THIS Saturday, at 9pm, for a Steelstacks show with the fine young men of ManDudeBro!'),
(678, 126, '_featured_content', 'field_553540d394dd4'),
(679, 126, 'facebook_feed', '[fb_feed]'),
(680, 126, '_facebook_feed', 'field_553d32f209498'),
(681, 126, 'twitter_feed', '[AIGetTwitterFeeds ai_username=\'highdramma\' ai_numberoftweets=\'3\' ai_tweet_title=\'HD Tweets\']'),
(682, 126, '_twitter_feed', 'field_553d332f0949a'),
(683, 126, 'youtube_feed_0_youtube_video', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(684, 126, '_youtube_feed_0_youtube_video', 'field_554a52f8f749b'),
(685, 126, 'youtube_feed_1_youtube_video', 'https://www.youtube.com/watch?v=0t2GjQCzXsc'),
(686, 126, '_youtube_feed_1_youtube_video', 'field_554a52f8f749b'),
(687, 126, 'youtube_feed', '2'),
(688, 126, '_youtube_feed', 'field_553d332309499'),
(689, 126, 'social_media_feeds', '0'),
(690, 126, '_social_media_feeds', 'field_553d493377464'),
(691, 126, 'homepage_introduction', 'High Dramma is a team of actors/writers/comedians who have banded together in order to bring you the finest independent sketch comedy in the world (well, at least in Philadelphia).\r\n\r\nSo come on down and check us out! You can be sure to get a laugh...or two, because we take comedy so seriously, it\'s not even funny.'),
(692, 126, '_homepage_introduction', 'field_55353a9ea92f4'),
(693, 19, 'youtube_feed_0_youtube_video', 'https://www.youtube.com/watch?v=Ri0Rk_j6ezk'),
(694, 19, '_youtube_feed_0_youtube_video', 'field_554a52f8f749b'),
(695, 19, 'youtube_feed_1_youtube_video', 'https://www.youtube.com/watch?v=0t2GjQCzXsc'),
(696, 19, '_youtube_feed_1_youtube_video', 'field_554a52f8f749b'),
(701, 129, '_wp_attached_file', '2015/05/hd-site-icon-554ba897v1_site_icon.png'),
(702, 129, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:45:"2015/05/hd-site-icon-554ba897v1_site_icon.png";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:45:"hd-site-icon-554ba897v1_site_icon-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-256";a:4:{s:4:"file";s:45:"hd-site-icon-554ba897v1_site_icon-256x256.png";s:5:"width";i:256;s:6:"height";i:256;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-128";a:4:{s:4:"file";s:45:"hd-site-icon-554ba897v1_site_icon-128x128.png";s:5:"width";i:128;s:6:"height";i:128;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-80";a:4:{s:4:"file";s:43:"hd-site-icon-554ba897v1_site_icon-80x80.png";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-64";a:4:{s:4:"file";s:43:"hd-site-icon-554ba897v1_site_icon-64x64.png";s:5:"width";i:64;s:6:"height";i:64;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-32";a:4:{s:4:"file";s:43:"hd-site-icon-554ba897v1_site_icon-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-16";a:4:{s:4:"file";s:43:"hd-site-icon-554ba897v1_site_icon-16x16.png";s:5:"width";i:16;s:6:"height";i:16;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2015-04-13 18:19:28', '2015-04-13 18:19:28', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world', '', '', '2015-04-19 15:51:11', '2015-04-19 15:51:11', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=1', 0, 'post', '', 1),
(5, 1, '2015-04-17 17:49:19', '2015-04-17 17:49:19', '', 'hd-logo-200x208', '', 'inherit', 'open', 'open', '', 'hd-logo-200x208', '', '', '2015-04-17 17:49:19', '2015-04-17 17:49:19', '', 0, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/hd-logo-200x208.png', 0, 'attachment', 'image/png', 0),
(19, 1, '2015-04-17 17:59:18', '2015-04-17 17:59:18', '', 'Homepage', '', 'publish', 'open', 'open', '', 'home', '', '', '2015-05-06 17:46:26', '2015-05-06 17:46:26', '', 0, 'http://highdramma.lisawolfsonmyers.com/?page_id=19', 0, 'page', '', 0),
(20, 1, '2015-04-17 17:59:18', '2015-04-17 17:59:18', '', 'Home', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-17 17:59:18', '2015-04-17 17:59:18', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2015-04-17 17:59:32', '2015-04-17 17:59:32', '', 'Shows', '', 'publish', 'open', 'open', '', 'shows', '', '', '2015-04-17 17:59:32', '2015-04-17 17:59:32', '', 0, 'http://highdramma.lisawolfsonmyers.com/?page_id=21', 1, 'page', '', 0),
(22, 1, '2015-04-17 17:59:32', '2015-04-17 17:59:32', '', 'Shows', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2015-04-17 17:59:32', '2015-04-17 17:59:32', '', 21, 'http://highdramma.lisawolfsonmyers.com/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2015-04-17 17:59:44', '2015-04-17 17:59:44', '', 'Sketches', '', 'publish', 'open', 'open', '', 'sketches', '', '', '2015-05-02 02:29:56', '2015-05-02 02:29:56', '', 0, 'http://highdramma.lisawolfsonmyers.com/?page_id=23', 2, 'page', '', 0),
(24, 1, '2015-04-17 17:59:44', '2015-04-17 17:59:44', '', 'Sketches', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-04-17 17:59:44', '2015-04-17 17:59:44', '', 23, 'http://highdramma.lisawolfsonmyers.com/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2015-04-17 17:59:59', '2015-04-17 17:59:59', '', 'Meet The Group', '', 'publish', 'open', 'open', '', 'meet-the-group', '', '', '2015-04-17 17:59:59', '2015-04-17 17:59:59', '', 0, 'http://highdramma.lisawolfsonmyers.com/?page_id=25', 3, 'page', '', 0),
(26, 1, '2015-04-17 17:59:59', '2015-04-17 17:59:59', '', 'Meet The Group', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2015-04-17 17:59:59', '2015-04-17 17:59:59', '', 25, 'http://highdramma.lisawolfsonmyers.com/25-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2015-04-17 18:00:10', '2015-04-17 18:00:10', '', 'About HD', '', 'publish', 'open', 'open', '', 'about-hd', '', '', '2015-04-17 18:00:10', '2015-04-17 18:00:10', '', 0, 'http://highdramma.lisawolfsonmyers.com/?page_id=27', 4, 'page', '', 0),
(28, 1, '2015-04-17 18:00:10', '2015-04-17 18:00:10', '', 'About HD', '', 'inherit', 'open', 'open', '', '27-revision-v1', '', '', '2015-04-17 18:00:10', '2015-04-17 18:00:10', '', 27, 'http://highdramma.lisawolfsonmyers.com/27-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2015-04-17 18:00:48', '2015-04-17 18:00:48', ' ', '', '', 'publish', 'open', 'open', '', '29', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=29', 9, 'nav_menu_item', '', 0),
(30, 1, '2015-04-17 18:00:48', '2015-04-17 18:00:48', ' ', '', '', 'publish', 'open', 'open', '', '30', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=30', 3, 'nav_menu_item', '', 0),
(31, 1, '2015-04-17 18:00:48', '2015-04-17 18:00:48', ' ', '', '', 'publish', 'open', 'open', '', '31', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=31', 2, 'nav_menu_item', '', 0),
(32, 1, '2015-04-17 18:00:48', '2015-04-17 18:00:48', ' ', '', '', 'publish', 'open', 'open', '', '32', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=32', 1, 'nav_menu_item', '', 0),
(33, 1, '2015-04-17 18:01:21', '2015-04-17 18:01:21', '', 'Auto Draft', '', 'trash', 'open', 'open', '', 'auto-draft', '', '', '2015-04-17 18:01:30', '2015-04-17 18:01:30', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=member&#038;p=33', 0, 'member', '', 0),
(34, 1, '2015-04-19 15:51:11', '2015-04-19 15:51:11', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2015-04-19 15:51:11', '2015-04-19 15:51:11', '', 1, 'http://highdramma.lisawolfsonmyers.com/1-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2015-04-19 15:57:09', '2015-04-19 15:57:09', 'a:6:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:6:"member";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";}', 'Member Bio', 'member-bio', 'publish', 'closed', 'closed', '', 'group_5533cf2dd00e1', '', '', '2015-04-19 17:45:49', '2015-04-19 17:45:49', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field-group&#038;p=35', 0, 'acf-field-group', '', 0),
(37, 1, '2015-04-19 15:57:09', '2015-04-19 15:57:09', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Member\'s Title', 'members_title', 'publish', 'open', 'open', '', 'field_5533cf7ab87d4', '', '', '2015-04-19 16:10:02', '2015-04-19 16:10:02', '', 35, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=37', 0, 'acf-field', '', 0),
(38, 1, '2015-04-19 15:57:09', '2015-04-19 15:57:09', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Quote/Motto', 'quote_motto', 'publish', 'open', 'open', '', 'field_5533cf93b87d5', '', '', '2015-04-19 16:10:02', '2015-04-19 16:10:02', '', 35, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=38', 1, 'acf-field', '', 0),
(39, 1, '2015-04-19 15:57:09', '2015-04-19 15:57:09', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:10:"uploadedTo";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Member Photo', 'member_photo', 'publish', 'open', 'open', '', 'field_5533cfd7b87d6', '', '', '2015-04-19 17:45:49', '2015-04-19 17:45:49', '', 35, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=39', 2, 'acf-field', '', 0),
(40, 1, '2015-04-19 15:57:09', '2015-04-19 15:57:09', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:0;}', 'Member Bio', 'member_bio', 'publish', 'open', 'open', '', 'field_5533d02db87d7', '', '', '2015-04-19 16:14:03', '2015-04-19 16:14:03', '', 35, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=40', 3, 'acf-field', '', 0),
(41, 1, '2015-04-19 16:08:58', '2015-04-19 16:08:58', '', 'Jackie', '', 'trash', 'open', 'open', '', 'jackie', '', '', '2015-04-19 16:09:13', '2015-04-19 16:09:13', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=41', 0, 'post', '', 0),
(42, 1, '2015-04-19 16:09:13', '2015-04-19 16:09:13', '', 'Jackie', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2015-04-19 16:09:13', '2015-04-19 16:09:13', '', 41, 'http://highdramma.lisawolfsonmyers.com/41-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2015-04-19 16:13:28', '2015-04-19 16:13:28', '', 'Jackie', '', 'publish', 'closed', 'closed', '', 'jackie', '', '', '2015-04-19 17:46:14', '2015-04-19 17:46:14', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=member&#038;p=44', 0, 'member', '', 0),
(45, 1, '2015-04-19 16:12:12', '2015-04-19 16:12:12', '', 'jax-madlibs-biopic', '', 'inherit', 'open', 'open', '', 'jax-madlibs-biopic', '', '', '2015-04-19 16:12:21', '2015-04-19 16:12:21', '', 44, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/jax-madlibs-biopic.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2015-04-19 16:20:45', '2015-04-19 16:20:45', 'a:6:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:6:"member";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";}', 'Member Favorites', 'member-favorites', 'publish', 'closed', 'closed', '', 'group_5533d5d32bddd', '', '', '2015-04-19 16:25:04', '2015-04-19 16:25:04', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field-group&#038;p=50', 0, 'acf-field-group', '', 0),
(51, 1, '2015-04-19 16:23:40', '2015-04-19 16:23:40', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:10:"Add Sketch";}', 'Favorite Sketches', 'favorite_sketches', 'publish', 'open', 'open', '', 'field_5533d5dffeaf4', '', '', '2015-04-19 16:25:04', '2015-04-19 16:25:04', '', 50, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=51', 0, 'acf-field', '', 0),
(52, 1, '2015-04-19 16:23:40', '2015-04-19 16:23:40', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Favorite Sketch', 'favorite_sketch', 'publish', 'open', 'open', '', 'field_5533d5f6feaf5', '', '', '2015-04-19 16:23:40', '2015-04-19 16:23:40', '', 51, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=52', 0, 'acf-field', '', 0),
(53, 1, '2015-04-19 16:23:40', '2015-04-19 16:23:40', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:13:"Add Character";}', 'Memorable Characters', 'memorable_characters', 'publish', 'open', 'open', '', 'field_5533d624feaf6', '', '', '2015-04-19 16:25:04', '2015-04-19 16:25:04', '', 50, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=53', 1, 'acf-field', '', 0),
(54, 1, '2015-04-19 16:23:40', '2015-04-19 16:23:40', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Memorable Character', 'memorable_character', 'publish', 'open', 'open', '', 'field_5533d637feaf7', '', '', '2015-04-19 16:23:40', '2015-04-19 16:23:40', '', 53, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=54', 0, 'acf-field', '', 0),
(55, 1, '2015-04-19 16:23:40', '2015-04-19 16:23:40', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:3:"row";s:12:"button_label";s:16:"Add Comedic Idol";}', 'Comedic Idols', 'comedic_idols', 'publish', 'open', 'open', '', 'field_5533d66dfeaf8', '', '', '2015-04-19 16:25:04', '2015-04-19 16:25:04', '', 50, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=55', 2, 'acf-field', '', 0),
(56, 1, '2015-04-19 16:23:40', '2015-04-19 16:23:40', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Comedic Idol', 'comedic_idol', 'publish', 'open', 'open', '', 'field_5533d67cfeaf9', '', '', '2015-04-19 16:23:40', '2015-04-19 16:23:40', '', 55, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=56', 0, 'acf-field', '', 0),
(57, 1, '2015-04-19 18:04:08', '2015-04-19 18:04:08', '', 'DC', '', 'publish', 'closed', 'closed', '', 'dc', '', '', '2015-04-19 18:04:08', '2015-04-19 18:04:08', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=member&#038;p=57', 0, 'member', '', 0),
(58, 1, '2015-04-19 18:04:17', '2015-04-19 18:04:17', '', 'Sarah', '', 'publish', 'closed', 'closed', '', 'sarah', '', '', '2015-04-19 18:04:17', '2015-04-19 18:04:17', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=member&#038;p=58', 0, 'member', '', 0),
(59, 1, '2015-04-19 18:04:25', '2015-04-19 18:04:25', '', 'Pete', '', 'publish', 'closed', 'closed', '', 'pete', '', '', '2015-04-19 18:04:25', '2015-04-19 18:04:25', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=member&#038;p=59', 0, 'member', '', 0),
(60, 1, '2015-04-19 18:04:33', '2015-04-19 18:04:33', '', 'Curt', '', 'publish', 'closed', 'closed', '', 'curt', '', '', '2015-04-19 18:04:33', '2015-04-19 18:04:33', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=member&#038;p=60', 0, 'member', '', 0),
(61, 1, '2015-04-19 18:08:12', '2015-04-19 18:08:12', ' ', '', '', 'publish', 'open', 'open', '', '61', '', '', '2015-04-19 18:08:12', '2015-04-19 18:08:12', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=61', 5, 'nav_menu_item', '', 0),
(62, 1, '2015-04-19 18:08:12', '2015-04-19 18:08:12', ' ', '', '', 'publish', 'open', 'open', '', '62', '', '', '2015-04-19 18:08:12', '2015-04-19 18:08:12', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=62', 4, 'nav_menu_item', '', 0),
(63, 1, '2015-04-19 18:08:12', '2015-04-19 18:08:12', ' ', '', '', 'publish', 'open', 'open', '', '63', '', '', '2015-04-19 18:08:12', '2015-04-19 18:08:12', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=63', 3, 'nav_menu_item', '', 0),
(64, 1, '2015-04-19 18:08:12', '2015-04-19 18:08:12', ' ', '', '', 'publish', 'open', 'open', '', '64', '', '', '2015-04-19 18:08:12', '2015-04-19 18:08:12', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=64', 1, 'nav_menu_item', '', 0),
(65, 1, '2015-04-19 18:08:12', '2015-04-19 18:08:12', ' ', '', '', 'publish', 'open', 'open', '', '65', '', '', '2015-04-19 18:08:12', '2015-04-19 18:08:12', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=65', 2, 'nav_menu_item', '', 0),
(66, 1, '2015-04-20 01:14:17', '2015-04-20 01:14:17', '', 'Facebook', '', 'publish', 'open', 'open', '', 'facebook', '', '', '2015-04-20 01:14:17', '2015-04-20 01:14:17', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=66', 1, 'nav_menu_item', '', 0),
(67, 1, '2015-04-20 01:14:17', '2015-04-20 01:14:17', '', 'Twitter', '', 'publish', 'open', 'open', '', 'twitter', '', '', '2015-04-20 01:14:17', '2015-04-20 01:14:17', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=67', 2, 'nav_menu_item', '', 0),
(68, 1, '2015-04-20 01:14:17', '2015-04-20 01:14:17', '', 'YouTube', '', 'publish', 'open', 'open', '', 'youtube', '', '', '2015-04-20 01:14:17', '2015-04-20 01:14:17', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=68', 3, 'nav_menu_item', '', 0),
(69, 1, '2015-04-20 17:48:18', '2015-04-20 17:48:18', 'a:6:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"19";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";}', 'Homepage', 'homepage', 'publish', 'closed', 'closed', '', 'group_55353a8cb063a', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field-group&#038;p=69', 0, 'acf-field-group', '', 0),
(70, 1, '2015-04-20 17:48:18', '2015-04-20 17:48:18', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:5:"basic";s:12:"media_upload";i:0;}', 'Homepage Introduction', 'homepage_introduction', 'publish', 'open', 'open', '', 'field_55353a9ea92f4', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 69, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=70', 7, 'acf-field', '', 0),
(75, 1, '2015-04-20 18:04:41', '2015-04-20 18:04:41', '', 'mandudebro-and-hd', '', 'inherit', 'open', 'open', '', 'mandudebro-and-hd', '', '', '2015-04-20 18:04:49', '2015-04-20 18:04:49', '', 19, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/mandudebro-and-hd.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2015-04-20 18:05:49', '2015-04-20 18:05:49', '', 'Home', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-20 18:05:49', '2015-04-20 18:05:49', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2015-04-20 18:09:41', '2015-04-20 18:09:41', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Featured Image', 'featured_image', 'publish', 'open', 'open', '', 'field_553540ab94dd2', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 69, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=77', 0, 'acf-field', '', 0),
(78, 1, '2015-04-20 18:09:41', '2015-04-20 18:09:41', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Featured Title', 'featured_title', 'publish', 'open', 'open', '', 'field_553540c194dd3', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 69, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=78', 1, 'acf-field', '', 0),
(79, 1, '2015-04-20 18:09:41', '2015-04-20 18:09:41', 'a:9:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;}', 'Featured Content', 'featured_content', 'publish', 'open', 'open', '', 'field_553540d394dd4', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 69, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=79', 2, 'acf-field', '', 0),
(80, 1, '2015-04-20 18:10:40', '2015-04-20 18:10:40', '', 'Home', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-20 18:10:40', '2015-04-20 18:10:40', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2015-04-20 18:16:52', '2015-04-20 18:16:52', '', 'Home', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-20 18:16:52', '2015-04-20 18:16:52', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2015-04-21 18:54:14', '2015-04-21 18:54:14', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-21 18:54:14', '2015-04-21 18:54:14', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2015-04-26 18:47:05', '2015-04-26 18:47:05', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 18:47:05', '2015-04-26 18:47:05', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2015-04-26 18:49:28', '2015-04-26 18:49:28', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Facebook Feed', 'facebook_feed', 'publish', 'open', 'open', '', 'field_553d32f209498', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 69, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=85', 3, 'acf-field', '', 0),
(86, 1, '2015-04-26 18:49:28', '2015-04-26 18:49:28', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";i:2;s:6:"layout";s:3:"row";s:12:"button_label";s:9:"Add Video";}', 'YouTube Feed', 'youtube_feed', 'publish', 'open', 'open', '', 'field_553d332309499', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 69, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=86', 5, 'acf-field', '', 0),
(87, 1, '2015-04-26 18:49:28', '2015-04-26 18:49:28', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Twitter Feed', 'twitter_feed', 'publish', 'open', 'open', '', 'field_553d332f0949a', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 69, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=87', 4, 'acf-field', '', 0),
(88, 1, '2015-04-26 18:59:29', '2015-04-26 18:59:29', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 18:59:29', '2015-04-26 18:59:29', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2015-04-26 19:23:42', '2015-04-26 19:23:42', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 19:23:42', '2015-04-26 19:23:42', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2015-04-26 19:26:50', '2015-04-26 19:26:50', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 19:26:50', '2015-04-26 19:26:50', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2015-04-26 19:34:17', '2015-04-26 19:34:17', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 19:34:17', '2015-04-26 19:34:17', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2015-04-26 19:37:18', '2015-04-26 19:37:18', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 19:37:18', '2015-04-26 19:37:18', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2015-04-26 19:47:04', '2015-04-26 19:47:04', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 19:47:04', '2015-04-26 19:47:04', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2015-04-26 20:25:02', '2015-04-26 20:25:02', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:22:"Add Social Media Feeds";}', 'Social Media Feeds', 'social_media_feeds', 'publish', 'open', 'open', '', 'field_553d493377464', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 69, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=94', 6, 'acf-field', '', 0),
(95, 1, '2015-04-26 20:25:02', '2015-04-26 20:25:02', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Social Media Name', 'social_media_name', 'publish', 'open', 'open', '', 'field_553d496677465', '', '', '2015-04-26 20:25:02', '2015-04-26 20:25:02', '', 94, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=95', 0, 'acf-field', '', 0),
(96, 1, '2015-04-26 20:25:02', '2015-04-26 20:25:02', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Social Media Shortcode', 'social_media_shortcode', 'publish', 'open', 'open', '', 'field_553d497a77466', '', '', '2015-04-26 20:25:02', '2015-04-26 20:25:02', '', 94, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=96', 1, 'acf-field', '', 0),
(97, 1, '2015-04-26 20:25:42', '2015-04-26 20:25:42', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 20:25:42', '2015-04-26 20:25:42', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2015-04-26 20:27:18', '2015-04-26 20:27:18', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 20:27:18', '2015-04-26 20:27:18', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2015-04-26 20:27:34', '2015-04-26 20:27:34', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 20:27:34', '2015-04-26 20:27:34', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2015-04-26 20:36:25', '2015-04-26 20:36:25', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-04-26 20:36:25', '2015-04-26 20:36:25', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(101, 1, '2015-05-01 17:20:06', '2015-05-01 17:20:06', ' ', '', '', 'publish', 'open', 'open', '', '101', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=101', 7, 'nav_menu_item', '', 0),
(102, 1, '2015-05-01 17:20:06', '2015-05-01 17:20:06', ' ', '', '', 'publish', 'open', 'open', '', '102', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=102', 8, 'nav_menu_item', '', 0),
(103, 1, '2015-05-01 17:20:06', '2015-05-01 17:20:06', ' ', '', '', 'publish', 'open', 'open', '', '103', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=103', 6, 'nav_menu_item', '', 0),
(104, 1, '2015-05-01 17:20:06', '2015-05-01 17:20:06', ' ', '', '', 'publish', 'open', 'open', '', '104', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=104', 4, 'nav_menu_item', '', 0),
(105, 1, '2015-05-01 17:20:06', '2015-05-01 17:20:06', ' ', '', '', 'publish', 'open', 'open', '', '105', '', '', '2015-05-01 17:20:06', '2015-05-01 17:20:06', '', 0, 'http://highdramma.lisawolfsonmyers.com/?p=105', 5, 'nav_menu_item', '', 0),
(106, 1, '2015-05-01 23:51:14', '2015-05-01 23:51:14', 'a:6:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"23";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:14:{i:0;s:9:"permalink";i:1;s:11:"the_content";i:2;s:7:"excerpt";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:15:"page_attributes";i:10;s:14:"featured_image";i:11;s:10:"categories";i:12;s:4:"tags";i:13;s:15:"send-trackbacks";}}', 'Sketches', 'sketches', 'publish', 'closed', 'closed', '', 'group_554410da8fc95', '', '', '2015-05-02 02:29:07', '2015-05-02 02:29:07', '', 0, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field-group&#038;p=106', 0, 'acf-field-group', '', 0),
(107, 1, '2015-05-01 23:51:14', '2015-05-01 23:51:14', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:14:"grid columns-5";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"block";s:12:"button_label";s:9:"Add Video";}', 'Sketch Videos', 'sketch_videos', 'publish', 'open', 'open', '', 'field_554410f00e8e1', '', '', '2015-05-02 02:29:07', '2015-05-02 02:29:07', '', 106, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=107', 1, 'acf-field', '', 0),
(108, 1, '2015-05-01 23:51:14', '2015-05-01 23:51:14', 'a:7:{s:4:"type";s:6:"oembed";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:5:"width";s:0:"";s:6:"height";s:0:"";}', 'Video of Sketch', 'video_of_sketch', 'publish', 'open', 'open', '', 'field_554411170e8e2', '', '', '2015-05-01 23:51:14', '2015-05-01 23:51:14', '', 107, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=108', 0, 'acf-field', '', 0),
(109, 1, '2015-05-01 23:51:14', '2015-05-01 23:51:14', 'a:16:{s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Gallery', 'gallery', 'publish', 'open', 'open', '', 'field_554411500e8e3', '', '', '2015-05-02 02:29:07', '2015-05-02 02:29:07', '', 106, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&#038;p=109', 3, 'acf-field', '', 0),
(110, 1, '2015-05-01 23:53:40', '2015-05-01 23:53:40', '', 'Sketches', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-05-01 23:53:40', '2015-05-01 23:53:40', '', 23, 'http://highdramma.lisawolfsonmyers.com/23-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2015-05-02 00:00:24', '2015-05-02 00:00:24', '', 'Bananas', 'Climax of "Bananas"', 'inherit', 'open', 'open', '', 'bananas', '', '', '2015-05-02 00:01:22', '2015-05-02 00:01:22', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/bananas.jpg', 0, 'attachment', 'image/jpeg', 0),
(112, 1, '2015-05-02 00:00:27', '2015-05-02 00:00:27', '', 'Broken Fish', 'A fish versus a cop', 'inherit', 'open', 'open', '', 'broken-fish', '', '', '2015-05-02 00:01:48', '2015-05-02 00:01:48', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/broken-fish.jpg', 0, 'attachment', 'image/jpeg', 0),
(113, 1, '2015-05-02 00:00:28', '2015-05-02 00:00:28', '', 'Cannibals', 'Part of "Cannibals"', 'inherit', 'open', 'open', '', 'cannibals', '', '', '2015-05-02 00:02:19', '2015-05-02 00:02:19', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/cannibals.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 1, '2015-05-02 00:00:29', '2015-05-02 00:00:29', '', 'High Five', 'Sometimes you have to look at the whole picture when creating a slogan.', 'inherit', 'open', 'open', '', 'high-five', '', '', '2015-05-02 00:03:20', '2015-05-02 00:03:20', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/high-five.jpg', 0, 'attachment', 'image/jpeg', 0),
(115, 1, '2015-05-02 00:00:29', '2015-05-02 00:00:29', '', 'High Five 2', 'The group discusses their new slogan', 'inherit', 'open', 'open', '', 'high-five2', '', '', '2015-05-02 00:03:45', '2015-05-02 00:03:45', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/high-five2.jpg', 0, 'attachment', 'image/jpeg', 0),
(116, 1, '2015-05-02 00:00:30', '2015-05-02 00:00:30', '', 'Mexican Holdup', 'Sometimes you just need Mexican hot cocoa', 'inherit', 'open', 'open', '', 'mexican-holdup', '', '', '2015-05-02 00:04:20', '2015-05-02 00:04:20', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/mexican-holdup.jpg', 0, 'attachment', 'image/jpeg', 0),
(117, 1, '2015-05-02 00:00:30', '2015-05-02 00:00:30', '', 'Nuts', 'The girls try to persuade a grad to sample their wares', 'inherit', 'open', 'open', '', 'nuts', '', '', '2015-05-02 00:04:49', '2015-05-02 00:04:49', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/nuts.jpg', 0, 'attachment', 'image/jpeg', 0),
(118, 1, '2015-05-02 00:00:31', '2015-05-02 00:00:31', '', 'Poor Luigi', 'Mario isn\'t so comforting when his brother comes to him with a problem.', 'inherit', 'open', 'open', '', 'poor-luigi', '', '', '2015-05-02 00:05:16', '2015-05-02 00:05:16', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/poor-luigi.jpg', 0, 'attachment', 'image/jpeg', 0),
(119, 1, '2015-05-02 00:00:31', '2015-05-02 00:00:31', '', 'Singing Suit', 'A suit salesman tries to peddle his product.', 'inherit', 'open', 'open', '', 'singing-suit', '', '', '2015-05-02 00:05:51', '2015-05-02 00:05:51', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/singing-suit.jpg', 0, 'attachment', 'image/jpeg', 0),
(120, 1, '2015-05-02 00:00:32', '2015-05-02 00:00:32', '', 'The Lineup', 'A classic case of who-done-it', 'inherit', 'open', 'open', '', 'the-lineup', '', '', '2015-05-02 00:06:17', '2015-05-02 00:06:17', '', 23, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/04/the-lineup.jpg', 0, 'attachment', 'image/jpeg', 0),
(121, 1, '2015-05-02 00:06:21', '2015-05-02 00:06:21', '', 'Sketches', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-05-02 00:06:21', '2015-05-02 00:06:21', '', 23, 'http://highdramma.lisawolfsonmyers.com/23-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2015-05-02 02:29:07', '2015-05-02 02:29:07', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Sketch Videos Title', 'sketch_videos_title', 'publish', 'open', 'open', '', 'field_55443634e80ac', '', '', '2015-05-02 02:29:07', '2015-05-02 02:29:07', '', 106, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=122', 0, 'acf-field', '', 0),
(123, 1, '2015-05-02 02:29:07', '2015-05-02 02:29:07', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Sketch Photos Title', 'sketch_photos_title', 'publish', 'open', 'open', '', 'field_55443651e80ad', '', '', '2015-05-02 02:29:07', '2015-05-02 02:29:07', '', 106, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=123', 2, 'acf-field', '', 0),
(124, 1, '2015-05-02 02:29:56', '2015-05-02 02:29:56', '', 'Sketches', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-05-02 02:29:56', '2015-05-02 02:29:56', '', 23, 'http://highdramma.lisawolfsonmyers.com/23-revision-v1/', 0, 'revision', '', 0),
(125, 1, '2015-05-06 17:45:22', '2015-05-06 17:45:22', 'a:7:{s:4:"type";s:6:"oembed";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:5:"width";s:0:"";s:6:"height";s:0:"";}', 'YouTube Video', 'youtube_video', 'publish', 'open', 'open', '', 'field_554a52f8f749b', '', '', '2015-05-06 17:45:22', '2015-05-06 17:45:22', '', 86, 'http://highdramma.lisawolfsonmyers.com/?post_type=acf-field&p=125', 0, 'acf-field', '', 0),
(126, 1, '2015-05-06 17:46:26', '2015-05-06 17:46:26', '', 'Homepage', '', 'inherit', 'open', 'open', '', '19-revision-v1', '', '', '2015-05-06 17:46:26', '2015-05-06 17:46:26', '', 19, 'http://highdramma.lisawolfsonmyers.com/19-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2015-05-07 18:01:59', '2015-05-07 18:01:59', '', 'Large Blog Image', '', 'inherit', 'open', 'open', '', 'large-blog-image', '', '', '2015-05-07 18:01:59', '2015-05-07 18:01:59', '', 0, 'http://highdramma.lisawolfsonmyers.com/wp-content/uploads/2015/05/hd-site-icon-554ba897v1_site_icon.png', 0, 'attachment', 'image/png', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(29, 2, 0),
(30, 2, 0),
(31, 2, 0),
(32, 2, 0),
(41, 1, 0),
(61, 4, 0),
(62, 4, 0),
(63, 4, 0),
(64, 4, 0),
(65, 4, 0),
(66, 5, 0),
(67, 5, 0),
(68, 5, 0),
(101, 2, 0),
(102, 2, 0),
(103, 2, 0),
(104, 2, 0),
(105, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 9),
(4, 4, 'nav_menu', '', 0, 5),
(5, 5, 'nav_menu', '', 0, 3) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'main-navigation', 'main-navigation', 0),
(4, 'Member Menu', 'member-menu', 0),
(5, 'Social Menu', 'social-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'lwolfson'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw'),
(13, 1, 'show_welcome_panel', '1'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '83'),
(17, 1, 'wp_user-settings', 'libraryContent=browse&hidetb=0&editor=tinymce'),
(18, 1, 'wp_user-settings-time', '1429553436'),
(19, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(21, 1, 'nav_menu_recently_edited', '2'),
(22, 1, 'session_tokens', 'a:2:{s:64:"bdfcde5d9de0ebbb048d1dc932dbb7f40f7b7f44a3d37299b14626d0b3f9d097";a:4:{s:10:"expiration";i:1431106601;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36";s:5:"login";i:1430933801;}s:64:"4b18aaa6a0ca2830cebf60df5bfe2ad1b55c1a244ffdaffc114b7549af00b2e3";a:4:{s:10:"expiration";i:1431194228;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36";s:5:"login";i:1431021428;}}'),
(23, 1, 'closedpostboxes_member', 'a:1:{i:0;s:11:"postexcerpt";}'),
(24, 1, 'metaboxhidden_member', 'a:1:{i:0;s:7:"slugdiv";}'),
(25, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(26, 1, 'closedpostboxes_nav-menus', 'a:0:{}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'lwolfson', '$P$BdQMc6ETI1x2Xt5uL2ZO1KFyRX08QV.', 'lwolfson', 'lwolfson@mcad.edu', '', '2015-04-13 18:19:28', '', 0, 'lwolfson') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in
#

